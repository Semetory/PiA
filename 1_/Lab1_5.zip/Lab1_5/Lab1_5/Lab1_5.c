#include <stdio.h>

void house() {
	puts("\t\t\t\t_________________________");
	puts("\t\t\t\t|\t\t\t|");
	puts("\t\t\t\t|\t\t\t|");
	puts("\t\t\t\t|\t\t\t|");
	puts("\t\t\t\t|\t_________\t|"); 
	puts("\t\t\t\t|\t|\t|\t|________________________________");
	puts("\t\t\t\t|\t|\t|\t|\t\t\t\t|");
	puts("\t\t\t\t|\t|\t|\t|\t\t\t\t|");
	puts("\t\t\t\t|\t|\t|\t|\t\t\t\t|");
	puts("\t\t\t\t|\t|_______|\t|\t\t\t\t|");
	puts("\t\t\t\t|\t\t\t|\t\t_________\t|");
	puts("\t\t\t\t|\t\t\t|\t\t|\t|\t|");
	puts("\t\t\t\t|\t\t\t|\t\t|\t|\t|");
	puts("\t\t\t\t|\t\t\t|\t\t|\t|\t|");
	puts("\t\t\t\t|\t\t\t|\t\t|\t|\t|");
	puts("\t\t\t\t|\t\t\t|\t\t|\t|\t|");
	puts("\t\t\t\t|\t\t\t|\t\t|\t|\t|");
	puts("\t\t\t\t|\t\t\t|\t\t|\t|\t|");
	puts("\t\t\t\t|_______________________|_______________|_______|_______|");


}


 main() {
	 house();
}